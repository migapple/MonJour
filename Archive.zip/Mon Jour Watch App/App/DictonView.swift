import SwiftUI

struct DictonView: View {
    @Environment(DailyStore.self) private var store
    @Environment(Router.self) private var router

    var body: some View {
        let lang = store.lang
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                Text(Date.now.formatted(.dateTime.weekday(.wide).day().month(.wide).locale(lang.locale)).capitalized)
                    .font(.caption2)
                    .foregroundStyle(Theme.gold)
                Text("« \(store.dicton) »")
                    .font(.system(size: 20, weight: .semibold, design: .serif).italic())
                    .foregroundStyle(Theme.text)
                    .fixedSize(horizontal: false, vertical: true)
                Button(L10n.t("next", lang)) { router.go(.horoscope) }
                    .buttonStyle(.borderedProminent)
                    .foregroundStyle(Theme.ink)
                    .padding(.top, 6)
            }
        }
        .navigationTitle(L10n.t("dicton", lang).capitalized)
        .onAppear { store.markDicton() }
    }
}
