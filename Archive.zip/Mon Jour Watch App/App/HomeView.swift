import SwiftUI

struct HomeView: View {
    @Environment(DailyStore.self) private var store
    @Environment(Router.self) private var router

    var body: some View {
        let lang = store.lang
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(Date.now.formatted(.dateTime.weekday(.wide).day().month(.wide).locale(lang.locale)).capitalized)
                        .font(.footnote)
                        .foregroundStyle(Theme.muted)
                    Spacer()
                    Label(L10n.f("streak", lang, store.displayStreak()), systemImage: "flame")
                        .font(.footnote.bold())
                        .foregroundStyle(Theme.gold)
                        .labelStyle(.titleAndIcon)
                }

                RubricRow(title: L10n.t("dicton", lang),
                          subtitle: store.dicton,
                          icon: "quote.opening",
                          done: store.dictonSeen) { router.go(.dicton) }

                RubricRow(title: DailyContent.signName(store.sign, lang).uppercased(),
                          subtitle: L10n.t("horoscope", lang).capitalized,
                          icon: "sparkles",
                          done: store.horoscopeSeen) { router.go(.horoscope) }

                RubricRow(title: L10n.f("puzzle", lang, store.puzzleNumber),
                          subtitle: L10n.t(store.puzzleFinished ? "puzzleSolved" : "puzzleToPlay", lang),
                          icon: "square.grid.3x3",
                          done: store.puzzleFinished) { router.go(.puzzle) }

                ProgressView(value: Double(store.completedCount), total: 3)
                    .tint(Theme.gold)
                    .padding(.top, 4)
                Text(L10n.f("progress", lang, store.completedCount))
                    .font(.caption2)
                    .foregroundStyle(Theme.muted)
                    .frame(maxWidth: .infinity)
            }
        }
        .navigationTitle(L10n.t("appName", lang))
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button(lang.flag) { store.setLang(lang.toggled) }
                    .accessibilityLabel(lang == .fr ? "English" : "Français")
            }
        }
    }
}

private struct RubricRow: View {
    let title: String
    let subtitle: String
    let icon: String
    let done: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                ZStack {
                    Circle()
                        .fill(done ? Theme.good : .clear)
                        .overlay(Circle().strokeBorder(done ? .clear : Theme.gold, lineWidth: 2))
                    Image(systemName: done ? "checkmark" : icon)
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(done ? .white : Theme.gold)
                }
                .frame(width: 32, height: 32)

                VStack(alignment: .leading, spacing: 1) {
                    Text(title)
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Theme.gold)
                    Text(subtitle)
                        .font(.system(size: 14))
                        .foregroundStyle(Theme.text)
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
            }
            .padding(10)
            .background(Theme.card, in: RoundedRectangle(cornerRadius: 14))
        }
        .buttonStyle(.plain)
    }
}
