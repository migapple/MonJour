import SwiftUI

/// Horoscope du Jour intégré : mêmes pages verticales (en-tête, amour, travail, énergie, conseil),
/// textes générés par HoroscopeEngine. La couronne fait défiler les pages.
struct HoroscopeView: View {
    @Environment(DailyStore.self) private var store
    @Environment(Router.self) private var router
    @State private var pickingSign = false

    var body: some View {
        let lang = store.lang
        let h = store.horoscope

        TabView {
            HeaderPage(h: h, lang: lang) { pickingSign = true }
            SectionPage(icon: "heart.fill", title: lang.t("Amour", "Love"),
                        score: h.loveScore, text: h.love.text(lang))
            SectionPage(icon: "briefcase.fill", title: lang.t("Travail", "Work"),
                        score: h.workScore, text: h.work.text(lang))
            SectionPage(icon: "bolt.fill", title: lang.t("Énergie", "Energy"),
                        score: h.energyScore, text: h.energy.text(lang))
            AdvicePage(h: h, lang: lang) { router.go(.puzzle) }
        }
        .tabViewStyle(.verticalPage)
        .navigationTitle(L10n.t("horoscope", lang).capitalized)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { pickingSign = true } label: {
                    // Blanc obligatoire : le fond du bouton prend la teinte or de l'app,
                    // une icône or y serait invisible (même souci que dans Horoscope du Jour).
                    Image(systemName: "sparkles")
                        .foregroundStyle(.white)
                }
                .accessibilityLabel(lang.t("Changer de signe", "Change sign"))
            }
        }
        .onAppear {
            store.markHoroscope()
            if !store.signChosen { pickingSign = true }
        }
        .sheet(isPresented: $pickingSign) {
            List(Zodiac.allCases) { z in
                Button {
                    store.setSign(z.rawValue)
                    pickingSign = false
                } label: {
                    HStack {
                        Text(z.symbol).foregroundStyle(Theme.gold)
                        VStack(alignment: .leading) {
                            Text(z.name(lang))
                            Text(z.dates(lang))
                                .font(.caption2)
                                .foregroundStyle(Theme.muted)
                        }
                        Spacer()
                        if z.rawValue == store.sign {
                            Image(systemName: "checkmark").foregroundStyle(Theme.gold)
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Pages

private struct HeaderPage: View {
    let h: DailyHoroscope
    let lang: Lang
    let changeSign: () -> Void

    var body: some View {
        ScrollView {
            VStack(spacing: 4) {
                Button(action: changeSign) {
                    VStack(spacing: 2) {
                        Text(h.sign.symbol)
                            .font(.system(size: 40))
                            .foregroundStyle(Theme.gold)
                        Text(h.sign.name(lang))
                            .font(.system(.title3, design: .serif).bold())
                            .foregroundStyle(Theme.text)
                    }
                }
                .buttonStyle(.plain)
                .accessibilityHint(lang.t("Changer de signe", "Change sign"))

                Stars(score: h.overall)
                    .padding(.vertical, 2)
                Text(h.intro.text(lang))
                    .font(.footnote)
                    .foregroundStyle(Theme.text)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity)
        }
    }
}

private struct SectionPage: View {
    let icon: String
    let title: String
    let score: Int
    let text: String

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 6) {
                    Image(systemName: icon)
                    Text(title).font(.system(.headline, design: .serif))
                }
                .foregroundStyle(Theme.gold)
                Stars(score: score)
                Text(text)
                    .font(.system(size: 15))
                    .foregroundStyle(Theme.text)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 4)
        }
    }
}

private struct AdvicePage: View {
    let h: DailyHoroscope
    let lang: Lang
    let next: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 6) {
                    Image(systemName: "sparkles")
                    Text(lang.t("Conseil du jour", "Today's advice"))
                        .font(.system(.headline, design: .serif))
                }
                .foregroundStyle(Theme.gold)

                Text(h.advice.text(lang))
                    .font(.system(size: 15))
                    .foregroundStyle(Theme.text)
                    .fixedSize(horizontal: false, vertical: true)

                HStack {
                    Text(lang.t("Chiffre", "Number")).foregroundStyle(Theme.muted)
                    Spacer()
                    Text("\(h.luckyNumber)").bold().foregroundStyle(Theme.gold)
                }
                .font(.footnote)
                HStack {
                    Text(lang.t("Couleur", "Colour")).foregroundStyle(Theme.muted)
                    Spacer()
                    Circle().fill(h.luckyColor.color).frame(width: 12, height: 12)
                    Text(h.luckyColor.name.text(lang)).foregroundStyle(Theme.text)
                }
                .font(.footnote)

                Button(L10n.t("nextPuzzle", lang), action: next)
                    .buttonStyle(.borderedProminent)
                    .foregroundStyle(Theme.ink)
                    .padding(.top, 4)

                Text(lang.t("Pour le plaisir uniquement.", "For entertainment only."))
                    .font(.system(size: 10))
                    .foregroundStyle(Theme.muted)
            }
            .padding(.horizontal, 4)
        }
    }
}

private struct Stars: View {
    let score: Int

    var body: some View {
        HStack(spacing: 2) {
            ForEach(1...5, id: \.self) { i in
                Image(systemName: i <= score ? "star.fill" : "star")
            }
        }
        .font(.caption2)
        .foregroundStyle(Theme.gold)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(score)/5")
    }
}
