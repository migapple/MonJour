import SwiftUI

@main
struct MonJourApp: App {
    @State private var store = DailyStore()
    @State private var router = Router()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            NavigationStack(path: $router.path) {
                HomeView()
                    .navigationDestination(for: Route.self) { route in
                        switch route {
                        case .dicton: DictonView()
                        case .horoscope: HoroscopeView()
                        case .puzzle: PuzzleView()
                        }
                    }
            }
            .environment(store)
            .environment(router)
            .tint(Theme.gold)
            .onChange(of: scenePhase) { _, phase in
                if phase == .active { store.refresh() }
            }
        }
    }
}
