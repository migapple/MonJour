import SwiftUI
import WatchKit

/// Mot mystère : 5 lettres, 6 essais. La Digital Crown choisit la lettre de la case active,
/// on touche une case pour la sélectionner. Pas de ScrollView ici, pour laisser la couronne au jeu.
struct PuzzleView: View {
    @Environment(DailyStore.self) private var store
    @State private var letters: [Character?] = Array(repeating: nil, count: DailyContent.wordLength)
    @State private var cursor = 0
    @State private var crown: Double = 0
    @State private var message: String?
    @FocusState private var gridFocused: Bool
    /// L'aide « Couronne : choisir la lettre » n'apparaît que tant que la couronne n'a jamais été utilisée.
    @AppStorage("crownHintSeen") private var crownHintSeen = false
    /// Bandeau de lettres affiché pendant qu'on tourne la couronne.
    @State private var letterIndex = 0
    @State private var stripVisible = false
    @State private var stripTask: Task<Void, Never>?
    /// Texte reçu de la dictée / Gribouiller / clavier.
    @State private var typed = ""
    @State private var showInput = false
    @FocusState private var inputFocused: Bool

    private let alphabet = Array("ABCDEFGHIJKLMNOPQRSTUVWXYZ")

    var body: some View {
        let lang = store.lang
        Group {
            if store.currentFinished {
                ResultView()
            } else {
                game
            }
        }
        .navigationTitle(title(lang))
        .onChange(of: store.practiceAnswer) { _, _ in
            // Nouvelle partie libre : on repart d'une ligne vide
            letters = Array(repeating: nil, count: DailyContent.wordLength)
            cursor = 0
            message = nil
            gridFocused = true
        }
    }

    private func title(_ lang: Lang) -> String {
        let tries = L10n.f("tries", lang, min(store.currentGuesses.count + 1, DailyContent.maxTries), DailyContent.maxTries)
        if store.isPractice {
            return store.currentFinished ? L10n.t("practice", lang) : tries
        }
        return store.currentFinished ? L10n.f("puzzle", lang, store.puzzleNumber) : tries
    }

    // MARK: Grille

    private var game: some View {
        GeometryReader { geo in
            let gap: CGFloat = 3
            let cols = CGFloat(DailyContent.wordLength)
            let rows = CGFloat(DailyContent.maxTries)
            let controlsHeight: CGFloat = 34
            let cellW = (geo.size.width - gap * (cols - 1)) / cols
            let cellH = max(16, min(cellW * 0.85, (geo.size.height - controlsHeight - 6 - gap * (rows - 1)) / rows))

            VStack(spacing: 6) {
                VStack(spacing: gap) {
                    ForEach(0..<DailyContent.maxTries, id: \.self) { row in
                        HStack(spacing: gap) {
                            ForEach(0..<DailyContent.wordLength, id: \.self) { col in
                                cell(row: row, col: col, fontSize: cellH * 0.6)
                                    .frame(width: cellW, height: cellH)
                            }
                        }
                    }
                }
                // Toucher n'importe où dans une colonne de la grille sélectionne cette case
                // de la ligne en cours : cible bien plus grande qu'une case seule.
                .contentShape(Rectangle())
                .onTapGesture(coordinateSpace: .local) { location in
                    let col = Int(location.x / (cellW + gap))
                    select(min(max(col, 0), DailyContent.wordLength - 1))
                    gridFocused = true
                }
                .focusable()
                .focused($gridFocused)
                .digitalCrownRotation($crown,
                                      from: 0,
                                      through: Double(alphabet.count - 1),
                                      by: 1,
                                      sensitivity: .low,   // plus de rotation par lettre = choix plus précis
                                      isContinuous: true,
                                      isHapticFeedbackEnabled: true)
                .overlay {
                    if let message {
                        Text(message)
                            .font(.footnote.bold())
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(Theme.ink.opacity(0.9), in: Capsule())
                            .foregroundStyle(Theme.text)
                    } else if !crownHintSeen {
                        // Aide affichée uniquement avant la toute première utilisation de la couronne
                        Label(L10n.t("crownHint", store.lang), systemImage: "digitalcrown.arrow.clockwise")
                            .font(.system(size: 12, weight: .semibold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(Theme.card.opacity(0.95), in: Capsule())
                            .foregroundStyle(Theme.gold)
                            .frame(maxHeight: .infinity, alignment: .bottom)
                            .allowsHitTesting(false)
                    }
                }

                // Pendant la rotation de la couronne, le bandeau de lettres remplace les boutons :
                // il est sous la grille et ne cache jamais la saisie.
                Group {
                    if stripVisible {
                        letterStrip
                    } else {
                        controls
                    }
                }
                .frame(height: controlsHeight)
            }
        }
        .onAppear {
            gridFocused = true
            prefillRow()
        }
        .onChange(of: crown) { _, value in
            let i = ((Int(value.rounded()) % alphabet.count) + alphabet.count) % alphabet.count
            guard letters[cursor] != alphabet[i] else { return }
            letters[cursor] = alphabet[i]
            letterIndex = i
            message = nil
            crownHintSeen = true
            showStrip()
        }
    }

    /// Lettres voisines autour de la lettre choisie (ex. A B [C] D E), pour voir où l'on est dans l'alphabet.
    private var letterStrip: some View {
        HStack(spacing: 4) {
            ForEach(-2...2, id: \.self) { offset in
                let ch = alphabet[(letterIndex + offset + alphabet.count) % alphabet.count]
                Text(String(ch))
                    .font(.system(size: offset == 0 ? 22 : 15, weight: offset == 0 ? .bold : .medium, design: .rounded))
                    .foregroundStyle(offset == 0 ? Theme.ink : Theme.muted)
                    .frame(width: offset == 0 ? 40 : 24, height: 34)
                    .background(offset == 0 ? Theme.gold : .clear, in: RoundedRectangle(cornerRadius: 8))
            }
        }
        .frame(maxWidth: .infinity)
        .background(Theme.card, in: Capsule())
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }

    private func showStrip() {
        stripVisible = true
        stripTask?.cancel()
        stripTask = Task {
            try? await Task.sleep(for: .milliseconds(900))
            if !Task.isCancelled { stripVisible = false }
        }
    }

    @ViewBuilder
    private func cell(row: Int, col: Int, fontSize: CGFloat) -> some View {
        let played = store.currentGuesses.count
        if row < played {
            let guess = Array(store.currentGuesses[row])
            let marks = DailyContent.score(guess, Array(store.currentAnswer))
            let mark = marks[col]
            tile(String(guess[col]),
                 fill: mark == .good ? Theme.good : (mark == .near ? Theme.gold : Theme.empty),
                 foreground: mark == .near ? Theme.ink : (mark == .good ? .white : Theme.muted),
                 border: nil,
                 fontSize: fontSize)
        } else if row == played {
            tile(letters[col].map { String($0) } ?? "",
                 fill: col == cursor ? Theme.card : .clear,
                 foreground: Theme.text,
                 border: col == cursor ? Theme.text : Theme.gold,
                 fontSize: fontSize)
                .accessibilityAddTraits(.isButton)
        } else {
            tile("", fill: .clear, foreground: .clear, border: Theme.empty, fontSize: fontSize)
        }
    }

    private func tile(_ s: String, fill: Color, foreground: Color, border: Color?, fontSize: CGFloat) -> some View {
        RoundedRectangle(cornerRadius: 5)
            .fill(fill)
            .overlay {
                if let border {
                    RoundedRectangle(cornerRadius: 5).strokeBorder(border, lineWidth: 1.5)
                }
            }
            .overlay(
                Text(s)
                    .font(.system(size: fontSize, weight: .bold, design: .rounded))
                    .foregroundStyle(foreground)
            )
    }

    // MARK: Commandes

    private var controls: some View {
        let lang = store.lang
        let complete = letters.allSatisfy { $0 != nil }
        return HStack(spacing: 6) {
            Button(action: erase) {
                pill(Image(systemName: "delete.left"), fill: Theme.card, fg: Theme.gold)
            }
            .accessibilityLabel(L10n.t("erase", lang))

            Button {
                select(max(cursor - 1, 0))
            } label: {
                pill(Image(systemName: "arrow.left"), fill: Theme.card, fg: Theme.gold)
            }
            .accessibilityLabel(L10n.t("prevLetter", lang))

            if complete {
                Button(action: validate) {
                    pill(Text(L10n.t("validate", lang)).bold(), fill: Theme.gold, fg: Theme.ink)
                }
            } else {
                Button {
                    select(min(cursor + 1, DailyContent.wordLength - 1))
                } label: {
                    pill(Image(systemName: "arrow.right"), fill: Theme.card, fg: Theme.gold)
                }
                .accessibilityLabel(L10n.t("nextLetter", lang))

                Button {
                    typed = ""
                    showInput = true
                } label: {
                    pill(Image(systemName: "mic.fill"), fill: Theme.card, fg: Theme.gold)
                }
                .accessibilityLabel(L10n.t("voiceInput", lang))
            }
        }
        .buttonStyle(.plain)
        .sheet(isPresented: $showInput) { inputSheet }
    }

    /// Écran de saisie : champ standard watchOS (dictée, Gribouiller, clavier selon le modèle).
    private var inputSheet: some View {
        let lang = store.lang
        return VStack(spacing: 10) {
            Text(L10n.t("voiceInput", lang))
                .font(.footnote)
                .foregroundStyle(Theme.muted)
                .multilineTextAlignment(.center)
            TextField(lang.t("Mot ou lettres", "Word or letters"), text: $typed)
                .focused($inputFocused)
                .onSubmit {
                    applyTyped()
                    showInput = false
                }
                // Sur la montre, le texte arrive d'un bloc à la fin de la dictée : on l'applique aussitôt.
                .onChange(of: typed) { _, new in
                    guard !new.isEmpty else { return }
                    applyTyped()
                    showInput = false
                }
            Text(lang.t("Ex. « poire » ou « P O I R E »", "E.g. \u{201C}light\u{201D} or \u{201C}L I G H T\u{201D}"))
                .font(.system(size: 11))
                .foregroundStyle(Theme.muted)
        }
        .onAppear { inputFocused = true }
    }

    /// Remplit la ligne avec ce qui a été dicté ou écrit : un mot (« poire ») ou des lettres
    /// épelées (« P, O, I, R, E »). Accents, espaces et ponctuation sont ignorés.
    private func applyTyped() {
        let raw = typed
        guard !raw.isEmpty else { return }
        typed = ""
        let clean = raw
            .folding(options: [.diacriticInsensitive, .caseInsensitive], locale: nil)
            .uppercased()
            .filter { alphabet.contains($0) }
        guard !clean.isEmpty else { return }

        // Un mot complet remplace la ligne ; quelques lettres se placent à partir de la case active.
        let start = clean.count >= DailyContent.wordLength ? 0 : cursor
        var col = start
        for ch in clean.prefix(DailyContent.wordLength - start) {
            letters[col] = ch
            col += 1
        }
        cursor = min(col, DailyContent.wordLength - 1)
        message = nil
        gridFocused = true
    }

    /// Bouton compact à hauteur fixe : les boutons watchOS standard sont trop hauts pour tenir sous la grille.
    private func pill<Content: View>(_ content: Content, fill: Color, fg: Color) -> some View {
        content
            .font(.system(size: 15, weight: .semibold))
            .foregroundStyle(fg)
            .frame(maxWidth: .infinity, minHeight: 34, maxHeight: 34)
            .background(fill, in: Capsule())
            .contentShape(Capsule())
    }

    /// Lettre déjà trouvée (verte) à cette position dans un essai précédent.
    private func knownLetter(at col: Int) -> Character? {
        let answer = Array(store.currentAnswer)
        for guess in store.currentGuesses.reversed() {
            let g = Array(guess)
            if g.count == answer.count && g[col] == answer[col] { return g[col] }
        }
        return nil
    }

    /// Sélectionne une case ; si elle est vide et que la lettre y a déjà été trouvée, la préremplit.
    private func select(_ col: Int) {
        cursor = col
        if letters[col] == nil, let known = knownLetter(at: col) {
            letters[col] = known
        }
        // La couronne repart de la lettre déjà présente dans la case, pour l'ajuster d'un cran
        if let l = letters[col], let idx = alphabet.firstIndex(of: l) {
            letterIndex = idx
            crown = Double(idx)
        }
    }

    /// Début de ligne : remplit toutes les lettres déjà trouvées (vertes)
    /// et place le curseur sur la première case encore vide.
    private func prefillRow() {
        for col in 0..<DailyContent.wordLength where letters[col] == nil {
            letters[col] = knownLetter(at: col)
        }
        cursor = letters.firstIndex(where: { $0 == nil }) ?? 0
    }

    private func erase() {
        if letters[cursor] == nil && cursor > 0 {
            cursor -= 1
        }
        letters[cursor] = nil
        message = nil
    }

    private func validate() {
        let word = String(letters.compactMap { $0 })
        switch store.submit(word) {
        case .accepted:
            letters = Array(repeating: nil, count: DailyContent.wordLength)
            if !store.currentFinished { prefillRow() }
            WKInterfaceDevice.current().play(store.currentSolved ? .success : .click)
        case .unknownWord:
            message = L10n.t("unknownWord", store.lang)
            WKInterfaceDevice.current().play(.failure)
        case .incomplete, .finished:
            break
        }
    }
}
