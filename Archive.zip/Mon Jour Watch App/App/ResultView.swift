import SwiftUI

struct ResultView: View {
    @Environment(DailyStore.self) private var store
    @Environment(Router.self) private var router

    var body: some View {
        let lang = store.lang
        let solved = store.currentSolved
        ScrollView {
            VStack(spacing: 8) {
                ZStack {
                    Circle().stroke(Theme.empty, lineWidth: 6)
                    Circle()
                        .trim(from: 0, to: CGFloat(store.completedCount) / 3)
                        .stroke(Theme.gold, style: StrokeStyle(lineWidth: 6, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                    Text("\(store.displayStreak())")
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .foregroundStyle(Theme.text)
                }
                .frame(width: 58, height: 58)
                .accessibilityElement(children: .ignore)
                .accessibilityLabel(L10n.f("streakDays", lang, store.displayStreak()))

                Text(L10n.t(solved ? "bravo" : "lost", lang))
                    .font(.system(size: 24, weight: .bold, design: .serif))
                    .foregroundStyle(Theme.gold)

                Text(solved ? L10n.f("foundIn", lang, store.currentGuesses.count) : L10n.t("wordWas", lang))
                    .font(.footnote)
                    .foregroundStyle(Theme.muted)

                HStack(spacing: 3) {
                    ForEach(Array(store.currentAnswer.enumerated()), id: \.offset) { _, ch in
                        Text(String(ch))
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .frame(width: 26, height: 26)
                            .background(solved ? Theme.good : Theme.empty, in: RoundedRectangle(cornerRadius: 5))
                    }
                }

                Text(store.isPractice
                     ? L10n.t("practiceNote", lang)
                     : L10n.f("streakDays", lang, store.displayStreak()) + " · " + L10n.t("nextAtMidnight", lang))
                    .font(.system(size: 11))
                    .foregroundStyle(Theme.muted)
                    .multilineTextAlignment(.center)

                Button(L10n.t("newPuzzle", lang)) { store.startPractice() }
                    .buttonStyle(.borderedProminent)
                    .foregroundStyle(Theme.ink)

                Button(L10n.t("done", lang)) {
                    store.endPractice()
                    router.home()
                }
                .buttonStyle(.bordered)
            }
        }
    }
}
