import Foundation

// MARK: - Modèles des fichiers JSON

/// Format de dictons.json (repris tel quel de Dicton du Jour).
struct DictonEntry: Codable, Hashable {
    let fr: String
    let en: String
    func text(_ lang: Lang) -> String { lang == .fr ? fr : en }
}

struct DictonData: Codable {
    /// Dictons liés à une date, clé "MM-dd"
    let calendrier: [String: DictonEntry]
    /// Proverbes en rotation les autres jours
    let proverbes: [DictonEntry]
}

/// Format de mots.json (mots de 5 lettres extraits des dictionnaires de Lettres Rami).
struct WordList: Codable {
    let answers: [String]   // mots à deviner, courants, ordre mélangé
    let allowed: [String]   // tous les mots acceptés en essai
}

struct WordData: Codable {
    let fr: WordList
    let en: WordList
}

enum Mark { case good, near, absent }

// MARK: - Contenu du jour

/// Ressources à mettre dans Shared/ : dictons.json (2 cibles) et mots.json (au moins l'app Watch).
enum DailyContent {
    static let wordLength = 5
    static let maxTries = 6

    /// true = seuls les vrais mots du dictionnaire sont acceptés en essai.
    static let strictDictionary = true

    private static func load<T: Decodable>(_ name: String, as type: T.Type) -> T? {
        guard let url = Bundle.main.url(forResource: name, withExtension: "json"),
              let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }

    private static func pick(_ n: Int, _ count: Int) -> Int {
        ((n % count) + count) % count
    }

    // MARK: Dicton

    static let dictons: DictonData = {
        if let d = load("dictons", as: DictonData.self), !d.proverbes.isEmpty { return d }
        return DictonData(calendrier: [:], proverbes: [
            DictonEntry(fr: "Petit à petit, l'oiseau fait son nid.",
                        en: "Little by little, the bird builds its nest.")
        ])
    }()

    /// Même algorithme que Dicton du Jour : le dicton de calendrier si la date en a un,
    /// sinon un proverbe en rotation (sans répétition dans l'année).
    static func dicton(on date: Date, calendar cal: Calendar = DayKey.calendar) -> DictonEntry {
        let c = cal.dateComponents([.year, .month, .day], from: date)
        let key = String(format: "%02d-%02d", c.month ?? 1, c.day ?? 1)
        if let special = dictons.calendrier[key] { return special }

        let year = c.year ?? 2026
        var rank = 0
        if let jan1 = cal.date(from: DateComponents(year: year, month: 1, day: 1)) {
            var day = jan1
            let target = cal.startOfDay(for: date)
            while day < target {
                let j = cal.dateComponents([.month, .day], from: day)
                if dictons.calendrier[String(format: "%02d-%02d", j.month ?? 1, j.day ?? 1)] == nil {
                    rank += 1
                }
                guard let next = cal.date(byAdding: .day, value: 1, to: day) else { break }
                day = next
            }
        }
        return dictons.proverbes[(rank + year * 37) % dictons.proverbes.count]
    }

    static func dicton(day: Int, lang: Lang) -> String {
        dicton(on: DayKey.date(for: day)).text(lang)
    }

    // MARK: Horoscope (moteur de Horoscope du Jour : HoroscopeEngine.swift + Zodiac.swift)

    static func zodiac(_ i: Int) -> Zodiac {
        Zodiac(rawValue: pick(i, 12)) ?? .libra
    }

    static func signName(_ i: Int, _ lang: Lang) -> String { zodiac(i).name(lang) }
    static func symbol(_ i: Int) -> String { zodiac(i).symbol }

    static func horoscope(day: Int, sign: Int) -> DailyHoroscope {
        HoroscopeEngine.horoscope(for: zodiac(sign), on: DayKey.date(for: day))
    }

    // MARK: Mot mystère

    private static let words: WordData? = load("mots", as: WordData.self)
    private static let allowedFR = Set(words?.fr.allowed ?? [])
    private static let allowedEN = Set(words?.en.allowed ?? [])

    private static let fallbackFR = ["PLUIE", "NUAGE", "FLEUR", "ARBRE", "POIRE", "LIVRE", "PLAGE", "NEIGE"]
    private static let fallbackEN = ["CRANE", "PLANT", "STORM", "LIGHT", "RIVER", "APPLE", "BREAD", "CHAIR"]

    static func answers(_ lang: Lang) -> [String] {
        let list = lang == .fr ? words?.fr.answers : words?.en.answers
        if let list, !list.isEmpty { return list }
        return lang == .fr ? fallbackFR : fallbackEN
    }

    static func answer(day: Int, lang: Lang) -> String {
        let list = answers(lang)
        return list[pick(day, list.count)]
    }

    /// Mot au hasard pour une partie libre.
    static func randomAnswer(lang: Lang, excluding: Set<String> = []) -> String {
        let list = answers(lang).filter { !excluding.contains($0) }
        return list.randomElement() ?? answers(lang)[0]
    }

    static func isAllowed(_ word: String, lang: Lang) -> Bool {
        guard strictDictionary, words != nil else { return true }
        let set = lang == .fr ? allowedFR : allowedEN
        return set.contains(word) || answers(lang).contains(word)
    }

    /// Notation façon Wordle, doublons gérés.
    static func score(_ guess: [Character], _ answer: [Character]) -> [Mark] {
        var result = Array(repeating: Mark.absent, count: guess.count)
        var remaining: [Character: Int] = [:]
        for i in guess.indices {
            if guess[i] == answer[i] {
                result[i] = .good
            } else {
                remaining[answer[i], default: 0] += 1
            }
        }
        for i in guess.indices where result[i] != .good {
            if let c = remaining[guess[i]], c > 0 {
                result[i] = .near
                remaining[guess[i]] = c - 1
            }
        }
        return result
    }
}
