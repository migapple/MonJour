import Foundation
import Observation
#if canImport(WidgetKit)
import WidgetKit
#endif

enum Route: Hashable {
    case dicton, horoscope, puzzle
}

enum SubmitResult {
    case accepted, incomplete, unknownWord, finished
}

/// État du jour + série, partagé avec l'extension de complications via l'App Group.
@Observable
final class DailyStore {
    static let appGroup = "group.com.michel.garlandat.monjour"

    private let defaults: UserDefaults

    private(set) var lang: Lang
    private(set) var sign: Int
    private(set) var signChosen: Bool
    private(set) var today: Int
    private(set) var dictonSeen = false
    private(set) var horoscopeSeen = false
    private(set) var guesses: [String] = []
    private(set) var puzzleLang: Lang
    private(set) var streak = 0
    private(set) var lastFullDay = -100_000

    private enum K {
        static let lang = "lang", sign = "sign", signChosen = "signChosen", day = "day"
        static let dicton = "dictonSeen", horoscope = "horoscopeSeen"
        static let guesses = "guesses", puzzleLang = "puzzleLang"
        static let streak = "streak", lastFull = "lastFullDay"
    }

    init(defaults: UserDefaults = UserDefaults(suiteName: DailyStore.appGroup) ?? .standard) {
        self.defaults = defaults
        let l = Lang(rawValue: defaults.string(forKey: K.lang) ?? "") ?? .system
        lang = l
        sign = defaults.object(forKey: K.sign) as? Int ?? 6
        signChosen = defaults.bool(forKey: K.signChosen)
        today = DayKey.index()
        puzzleLang = Lang(rawValue: defaults.string(forKey: K.puzzleLang) ?? "") ?? l
        streak = defaults.integer(forKey: K.streak)
        lastFullDay = defaults.object(forKey: K.lastFull) as? Int ?? -100_000
        loadDay()
    }

    // MARK: Lecture

    var dicton: String { DailyContent.dicton(day: today, lang: lang) }
    var horoscope: DailyHoroscope { DailyContent.horoscope(day: today, sign: sign) }
    var puzzleNumber: Int { today + 1 }
    var answer: String { DailyContent.answer(day: today, lang: puzzleLang) }
    var puzzleSolved: Bool { guesses.last == answer }
    var puzzleFinished: Bool { puzzleSolved || guesses.count >= DailyContent.maxTries }
    var completedCount: Int { [dictonSeen, horoscopeSeen, puzzleFinished].filter { $0 }.count }

    // MARK: Partie libre (après le puzzle du jour, sans effet sur la série)

    private(set) var practiceAnswer: String?
    private(set) var practiceGuesses: [String] = []
    private var practiceLang: Lang = .fr

    var isPractice: Bool { practiceAnswer != nil }

    /// Partie affichée par l'écran du puzzle : celle du jour, ou la partie libre en cours.
    var currentAnswer: String { practiceAnswer ?? answer }
    var currentGuesses: [String] { isPractice ? practiceGuesses : guesses }
    var currentSolved: Bool { currentGuesses.last == currentAnswer }
    var currentFinished: Bool { currentSolved || currentGuesses.count >= DailyContent.maxTries }

    func startPractice() {
        practiceLang = lang
        practiceAnswer = DailyContent.randomAnswer(lang: lang, excluding: [answer, practiceAnswer ?? ""])
        practiceGuesses = []
    }

    func endPractice() {
        practiceAnswer = nil
        practiceGuesses = []
    }

    /// Série affichée : reste valable tant que la veille a été complétée.
    func displayStreak(onDay day: Int? = nil) -> Int {
        lastFullDay >= (day ?? today) - 1 ? streak : 0
    }

    // MARK: Actions

    /// À appeler au retour au premier plan : bascule sur le nouveau jour après minuit.
    func refresh() {
        let now = DayKey.index()
        guard now != today else { return }
        today = now
        endPractice()
        loadDay()
        reloadWidgets()
    }

    func setLang(_ l: Lang) {
        lang = l
        defaults.set(l.rawValue, forKey: K.lang)
        if guesses.isEmpty {           // le puzzle reste dans sa langue une fois commencé
            puzzleLang = l
            defaults.set(l.rawValue, forKey: K.puzzleLang)
        }
        reloadWidgets()
    }

    func setSign(_ s: Int) {
        sign = ((s % 12) + 12) % 12
        signChosen = true
        defaults.set(sign, forKey: K.sign)
        defaults.set(true, forKey: K.signChosen)
        reloadWidgets()
    }

    func markDicton() {
        guard !dictonSeen else { return }
        dictonSeen = true
        defaults.set(true, forKey: K.dicton)
        didProgress()
    }

    func markHoroscope() {
        guard !horoscopeSeen else { return }
        horoscopeSeen = true
        defaults.set(true, forKey: K.horoscope)
        didProgress()
    }

    func submit(_ word: String) -> SubmitResult {
        let w = word.uppercased()
        guard w.count == DailyContent.wordLength else { return .incomplete }

        if isPractice {
            guard !currentFinished else { return .finished }
            guard DailyContent.isAllowed(w, lang: practiceLang) else { return .unknownWord }
            practiceGuesses.append(w)
            return .accepted
        }

        guard !puzzleFinished else { return .finished }
        guard DailyContent.isAllowed(w, lang: puzzleLang) else { return .unknownWord }
        guesses.append(w)
        defaults.set(guesses, forKey: K.guesses)
        didProgress()
        return .accepted
    }

    // MARK: Interne

    private func loadDay() {
        if defaults.object(forKey: K.day) as? Int == today {
            dictonSeen = defaults.bool(forKey: K.dicton)
            horoscopeSeen = defaults.bool(forKey: K.horoscope)
            guesses = defaults.stringArray(forKey: K.guesses) ?? []
        } else {
            dictonSeen = false
            horoscopeSeen = false
            guesses = []
            puzzleLang = lang
            defaults.set(today, forKey: K.day)
            defaults.set(false, forKey: K.dicton)
            defaults.set(false, forKey: K.horoscope)
            defaults.set([String](), forKey: K.guesses)
            defaults.set(lang.rawValue, forKey: K.puzzleLang)
        }
    }

    /// Une journée compte pour la série quand les 3 rubriques sont faites.
    private func didProgress() {
        if completedCount == 3 && lastFullDay != today {
            streak = (lastFullDay == today - 1) ? streak + 1 : 1
            lastFullDay = today
            defaults.set(streak, forKey: K.streak)
            defaults.set(today, forKey: K.lastFull)
        }
        reloadWidgets()
    }

    private func reloadWidgets() {
        #if canImport(WidgetKit)
        WidgetCenter.shared.reloadAllTimelines()
        #endif
    }
}

/// Pile de navigation, pour pouvoir revenir à l'accueil depuis l'écran de résultat.
@Observable
final class Router {
    var path: [Route] = []
    func go(_ r: Route) { path.append(r) }
    func home() { path.removeAll() }
}
