import Foundation

/// Numérotation des jours : 0 = 1er janvier 2026. Sert d'index pour tout le contenu du jour
/// (dicton, horoscope, mot mystère) et de numéro de puzzle (index + 1).
enum DayKey {
    static var calendar: Calendar {
        var c = Calendar(identifier: .gregorian)
        c.timeZone = .current
        return c
    }

    static let epoch: Date = {
        var c = Calendar(identifier: .gregorian)
        c.timeZone = .current
        return c.date(from: DateComponents(year: 2026, month: 1, day: 1))!
    }()

    static func index(for date: Date = .now) -> Int {
        let start = calendar.startOfDay(for: epoch)
        let day = calendar.startOfDay(for: date)
        return calendar.dateComponents([.day], from: start, to: day).day ?? 0
    }

    /// Date (début de journée) correspondant à un index de jour.
    static func date(for index: Int) -> Date {
        let start = calendar.startOfDay(for: epoch)
        return calendar.date(byAdding: .day, value: index, to: start) ?? start
    }

    static func nextMidnight(after date: Date = .now) -> Date {
        let tomorrow = calendar.date(byAdding: .day, value: 1, to: date) ?? date.addingTimeInterval(86_400)
        return calendar.startOfDay(for: tomorrow)
    }
}
