import SwiftUI

// MARK: - Générateur déterministe (même signe + même jour = même horoscope)

struct SeededRNG: RandomNumberGenerator {
    private var state: UInt64
    init(seed: UInt64) { state = seed }
    mutating func next() -> UInt64 {           // SplitMix64
        state &+= 0x9E3779B97F4A7C15
        var z = state
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        return z ^ (z >> 31)
    }
}

struct Phrase {
    let fr: String
    let en: String
    func text(_ lang: Lang) -> String { lang == .fr ? fr : en }
}

struct LuckyColor {
    let name: Phrase
    let color: Color
}

struct DailyHoroscope {
    let sign: Zodiac
    let date: Date
    let intro: Phrase
    let love: Phrase
    let work: Phrase
    let energy: Phrase
    let advice: Phrase
    let loveScore: Int
    let workScore: Int
    let energyScore: Int
    let luckyNumber: Int
    let luckyColor: LuckyColor

    var overall: Int {
        Int((Double(loveScore + workScore + energyScore) / 3).rounded())
    }
}

enum HoroscopeEngine {

    static func horoscope(for sign: Zodiac, on date: Date,
                          calendar: Calendar = .current) -> DailyHoroscope {
        let c = calendar.dateComponents([.year, .month, .day], from: date)
        let dayKey = UInt64((c.year ?? 2026) * 10_000 + (c.month ?? 1) * 100 + (c.day ?? 1))
        var rng = SeededRNG(seed: dayKey &* 1_000_003 &+ UInt64(sign.rawValue + 1) &* 7_919)

        func pick<T>(_ a: [T]) -> T { a[Int(rng.next() % UInt64(a.count))] }
        func score() -> Int { 2 + Int(rng.next() % 4) }   // 2 à 5 étoiles

        let intros: [Phrase]
        switch sign.element {
        case .fire:  intros = fireIntros
        case .earth: intros = earthIntros
        case .air:   intros = airIntros
        case .water: intros = waterIntros
        }

        return DailyHoroscope(
            sign: sign, date: date,
            intro: pick(intros),
            love: pick(love),
            work: pick(work),
            energy: pick(energy),
            advice: pick(advice),
            loveScore: score(),
            workScore: score(),
            energyScore: score(),
            luckyNumber: 1 + Int(rng.next() % 49),
            luckyColor: pick(colors)
        )
    }

    // MARK: - Textes (FR / EN alignés)

    static let fireIntros: [Phrase] = [
        .init(fr: "La journée démarre sur les chapeaux de roue : votre élan est contagieux.",
              en: "The day starts at full speed: your drive is contagious."),
        .init(fr: "Une étincelle d'audace vous pousse à prendre l'initiative.",
              en: "A spark of daring pushes you to take the lead."),
        .init(fr: "Le feu qui vous anime trouve aujourd'hui une belle direction.",
              en: "The fire within you finds a clear direction today."),
        .init(fr: "Votre enthousiasme ouvre des portes que vous pensiez fermées.",
              en: "Your enthusiasm opens doors you thought were shut.")
    ]

    static let earthIntros: [Phrase] = [
        .init(fr: "Une journée solide, idéale pour bâtir pierre après pierre.",
              en: "A steady day, ideal for building stone by stone."),
        .init(fr: "Votre patience porte enfin ses fruits.",
              en: "Your patience finally bears fruit."),
        .init(fr: "Le concret vous réussit : fiez-vous à votre bon sens.",
              en: "Practical matters suit you: trust your common sense."),
        .init(fr: "Un ancrage tranquille vous donne une vraie force intérieure.",
              en: "A calm grounding gives you real inner strength.")
    ]

    static let airIntros: [Phrase] = [
        .init(fr: "Les idées fusent et les échanges sont particulièrement fluides.",
              en: "Ideas flow and conversations run especially smoothly."),
        .init(fr: "Votre curiosité vous mène vers une rencontre inspirante.",
              en: "Your curiosity leads you to an inspiring encounter."),
        .init(fr: "Un vent de légèreté souffle sur votre journée.",
              en: "A light breeze of ease blows through your day."),
        .init(fr: "Votre esprit vif trouve des solutions là où d'autres hésitent.",
              en: "Your quick mind finds answers where others hesitate.")
    ]

    static let waterIntros: [Phrase] = [
        .init(fr: "Votre intuition est votre meilleure boussole aujourd'hui.",
              en: "Your intuition is your best compass today."),
        .init(fr: "Une vague de douceur apaise les tensions récentes.",
              en: "A wave of gentleness eases recent tensions."),
        .init(fr: "Vos émotions, bien écoutées, vous guident avec justesse.",
              en: "Your feelings, when heeded, guide you well."),
        .init(fr: "Une journée propice à l'introspection et aux confidences.",
              en: "A good day for reflection and heartfelt talks.")
    ]

    static let love: [Phrase] = [
        .init(fr: "Un geste tendre vaudra mieux qu'un long discours.",
              en: "A tender gesture will say more than a long speech."),
        .init(fr: "En couple, une complicité retrouvée illumine la soirée. Célibataire, un regard pourrait vous troubler.",
              en: "In a couple, renewed closeness brightens the evening. Single, a glance could catch you off guard."),
        .init(fr: "Osez dire ce que vous ressentez : vous serez bien reçu.",
              en: "Dare to say what you feel: it will be well received."),
        .init(fr: "Un petit malentendu se dissipe dès que vous écoutez vraiment.",
              en: "A small misunderstanding clears up once you truly listen."),
        .init(fr: "Vos proches ont besoin de votre attention ; elle vous sera rendue au centuple.",
              en: "Your loved ones need your attention; it will come back a hundredfold."),
        .init(fr: "Le charme opère sans effort. Profitez-en avec sincérité.",
              en: "Your charm works effortlessly. Use it sincerely."),
        .init(fr: "Prenez le temps d'un moment à deux, loin des écrans.",
              en: "Make time for a moment together, away from screens."),
        .init(fr: "Une surprise affectueuse pourrait bien égayer votre journée.",
              en: "An affectionate surprise may well brighten your day."),
        .init(fr: "Ne cherchez pas la perfection : la spontanéité vous réussit.",
              en: "Don't chase perfection: spontaneity suits you."),
        .init(fr: "Une conversation sincère renforce un lien précieux.",
              en: "An honest conversation strengthens a precious bond.")
    ]

    static let work: [Phrase] = [
        .init(fr: "Un dossier qui traînait se débloque enfin.",
              en: "A stalled project finally moves forward."),
        .init(fr: "Votre rigueur est remarquée : ne sous-estimez pas votre travail.",
              en: "Your rigor gets noticed: don't undervalue your work."),
        .init(fr: "Fixez une seule priorité et tenez-la jusqu'au bout.",
              en: "Set one priority and see it through."),
        .init(fr: "Une idée originale mérite d'être partagée en réunion.",
              en: "An original idea deserves to be shared at the meeting."),
        .init(fr: "Évitez de tout accepter : apprendre à dire non vous fera gagner du temps.",
              en: "Avoid saying yes to everything: learning to say no will save you time."),
        .init(fr: "Une collaboration inattendue se révèle fructueuse.",
              en: "An unexpected collaboration proves fruitful."),
        .init(fr: "C'est le bon moment pour terminer ce que vous avez commencé.",
              en: "It's the right time to finish what you started."),
        .init(fr: "Côté finances, prudence avant tout achat important.",
              en: "On the money side, be careful before any big purchase."),
        .init(fr: "Le conseil d'un collègue vous fait gagner un temps précieux.",
              en: "Advice from a colleague saves you valuable time."),
        .init(fr: "Votre persévérance commence à payer, continuez ainsi.",
              en: "Your persistence is starting to pay off; keep going.")
    ]

    static let energy: [Phrase] = [
        .init(fr: "Votre énergie est au beau fixe : bougez, marchez, respirez.",
              en: "Your energy is high: move, walk, breathe."),
        .init(fr: "Un léger coup de fatigue en milieu de journée : accordez-vous une pause.",
              en: "A slight midday dip: give yourself a break."),
        .init(fr: "Hydratez-vous et couchez-vous un peu plus tôt ce soir.",
              en: "Stay hydrated and get to bed a little earlier tonight."),
        .init(fr: "Un moment en plein air rechargera vos batteries.",
              en: "Some time outdoors will recharge your batteries."),
        .init(fr: "Le stress glisse sur vous ; votre calme impressionne.",
              en: "Stress slides off you; your calm is impressive."),
        .init(fr: "Écoutez votre corps : il sait ce dont il a besoin.",
              en: "Listen to your body: it knows what it needs."),
        .init(fr: "Quelques minutes de respiration profonde feront des merveilles.",
              en: "A few minutes of deep breathing will work wonders."),
        .init(fr: "Vitalité en hausse : jour idéal pour reprendre une bonne habitude.",
              en: "Vitality is rising: an ideal day to restart a good habit.")
    ]

    static let advice: [Phrase] = [
        .init(fr: "Faites une chose à la fois, et faites-la bien.",
              en: "Do one thing at a time, and do it well."),
        .init(fr: "Souriez à un inconnu : la journée vous le rendra.",
              en: "Smile at a stranger: the day will return it."),
        .init(fr: "Notez l'idée qui vous traverse l'esprit, elle pourrait compter.",
              en: "Write down that passing idea; it might matter."),
        .init(fr: "Ralentissez : ce qui compte vraiment ne s'enfuira pas.",
              en: "Slow down: what truly matters won't run away."),
        .init(fr: "Appelez quelqu'un à qui vous pensez depuis longtemps.",
              en: "Call someone you've been thinking about for a while."),
        .init(fr: "Rangez un petit coin de votre espace : l'esprit suivra.",
              en: "Tidy a small corner of your space: your mind will follow."),
        .init(fr: "Accordez-vous un plaisir simple, sans culpabiliser.",
              en: "Treat yourself to a simple pleasure, guilt-free."),
        .init(fr: "Faites confiance à votre premier élan.",
              en: "Trust your first instinct."),
        .init(fr: "Remerciez quelqu'un qui vous aide au quotidien.",
              en: "Thank someone who helps you every day."),
        .init(fr: "Laissez de côté ce que vous ne pouvez pas changer.",
              en: "Let go of what you cannot change."),
        .init(fr: "Apprenez quelque chose de nouveau, même minuscule.",
              en: "Learn something new, however small."),
        .init(fr: "Terminez la journée par un moment de calme.",
              en: "End the day with a quiet moment.")
    ]

    static let colors: [LuckyColor] = [
        .init(name: .init(fr: "Or",          en: "Gold"),          color: Color(red: 0.79, green: 0.64, blue: 0.36)),
        .init(name: .init(fr: "Bleu nuit",   en: "Midnight blue"), color: Color(red: 0.10, green: 0.15, blue: 0.40)),
        .init(name: .init(fr: "Émeraude",    en: "Emerald"),       color: Color(red: 0.08, green: 0.60, blue: 0.40)),
        .init(name: .init(fr: "Rouge corail",en: "Coral red"),     color: Color(red: 0.96, green: 0.38, blue: 0.32)),
        .init(name: .init(fr: "Lavande",     en: "Lavender"),      color: Color(red: 0.71, green: 0.61, blue: 0.86)),
        .init(name: .init(fr: "Turquoise",   en: "Turquoise"),     color: Color(red: 0.19, green: 0.78, blue: 0.76)),
        .init(name: .init(fr: "Ivoire",      en: "Ivory"),         color: Color(red: 0.96, green: 0.94, blue: 0.86)),
        .init(name: .init(fr: "Pourpre",     en: "Purple"),        color: Color(red: 0.50, green: 0.15, blue: 0.45)),
        .init(name: .init(fr: "Orange",      en: "Orange"),        color: Color(red: 0.98, green: 0.58, blue: 0.18)),
        .init(name: .init(fr: "Argent",      en: "Silver"),        color: Color(red: 0.75, green: 0.76, blue: 0.80))
    ]
}
