import Foundation

enum Lang: String {
    case fr, en

    var flag: String { self == .fr ? "🇫🇷" : "🇬🇧" }
    var toggled: Lang { self == .fr ? .en : .fr }
    var locale: Locale { Locale(identifier: self == .fr ? "fr_FR" : "en_GB") }

    /// Texte FR ou EN en ligne : lang.t("Amour", "Love")
    func t(_ fr: String, _ en: String) -> String { self == .fr ? fr : en }

    static var system: Lang {
        Locale.current.language.languageCode?.identifier == "fr" ? .fr : .en
    }
}

/// Textes d'interface FR/EN (même logique que le t() des apps Capacitor).
enum L10n {
    static func t(_ key: String, _ lang: Lang) -> String {
        (lang == .fr ? fr : en)[key] ?? key
    }

    static func f(_ key: String, _ lang: Lang, _ args: CVarArg...) -> String {
        String(format: t(key, lang), arguments: args)
    }

    private static let fr: [String: String] = [
        "appName": "Mon Jour",
        "dicton": "DICTON",
        "horoscope": "HOROSCOPE",
        "puzzle": "MOT N° %d",
        "puzzleToPlay": "Mot Mystère à jouer",
        "puzzleSolved": "Mot Mystère résolu",
        "progress": "%d sur 3 aujourd'hui",
        "streak": "%d j",
        "next": "Suivant",
        "nextPuzzle": "Suivant : le mot",
        "tapSign": "Touchez pour changer de signe",
        "love": "Amour", "work": "Travail", "energy": "Énergie",
        "tries": "Essai %d/%d",
        "crownHint": "Couronne : choisir la lettre",
        "erase": "Effacer",
        "nextLetter": "Lettre suivante",
        "prevLetter": "Lettre précédente",
        "voiceInput": "Dicter ou écrire le mot",
        "validate": "Valider",
        "unknownWord": "Mot inconnu",
        "bravo": "Bravo !",
        "lost": "Raté !",
        "foundIn": "Trouvé en %d essai(s)",
        "wordWas": "Le mot était",
        "streakDays": "%d jour(s) de suite",
        "nextAtMidnight": "Nouveau mot à minuit",
        "done": "Terminé",
        "newPuzzle": "Nouveau mot",
        "practice": "Partie libre",
        "practiceNote": "Partie libre : sans effet sur la série",
    ]

    private static let en: [String: String] = [
        "appName": "My Day",
        "dicton": "SAYING",
        "horoscope": "HOROSCOPE",
        "puzzle": "WORD #%d",
        "puzzleToPlay": "Mystery Word to play",
        "puzzleSolved": "Mystery Word done",
        "progress": "%d of 3 today",
        "streak": "%d d",
        "next": "Next",
        "nextPuzzle": "Next: the word",
        "tapSign": "Tap to change sign",
        "love": "Love", "work": "Work", "energy": "Energy",
        "tries": "Try %d/%d",
        "crownHint": "Crown: pick the letter",
        "erase": "Erase",
        "nextLetter": "Next letter",
        "prevLetter": "Previous letter",
        "voiceInput": "Dictate or write the word",
        "validate": "Submit",
        "unknownWord": "Not in word list",
        "bravo": "Well done!",
        "lost": "Missed!",
        "foundIn": "Solved in %d tries",
        "wordWas": "The word was",
        "streakDays": "%d day streak",
        "nextAtMidnight": "New word at midnight",
        "done": "Done",
        "newPuzzle": "New word",
        "practice": "Free play",
        "practiceNote": "Free play: does not affect your streak",
    ]
}
