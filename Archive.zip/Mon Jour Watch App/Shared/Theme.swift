import SwiftUI

/// Palette encre / or du catalogue, adaptée au fond noir watchOS.
enum Theme {
    static let gold  = Color(red: 0.788, green: 0.643, blue: 0.361)   // #c9a45c
    static let ink   = Color(red: 0.027, green: 0.020, blue: 0.063)   // #070510
    static let card  = Color(red: 0.078, green: 0.067, blue: 0.110)   // #14111c
    static let empty = Color(red: 0.165, green: 0.149, blue: 0.200)   // #2a2633
    static let text  = Color(red: 0.953, green: 0.918, blue: 0.847)   // #f3ead8
    static let muted = Color(red: 0.725, green: 0.678, blue: 0.592)   // #b9ad97
    static let good  = Color(red: 0.247, green: 0.541, blue: 0.361)   // #3f8a5c
}
