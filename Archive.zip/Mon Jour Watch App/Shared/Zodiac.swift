import Foundation

enum ZodiacElement { case fire, earth, air, water }

enum Zodiac: Int, CaseIterable, Identifiable {
    case aries, taurus, gemini, cancer, leo, virgo,
         libra, scorpio, sagittarius, capricorn, aquarius, pisces

    var id: Int { rawValue }

    var symbol: String {
        ["♈︎", "♉︎", "♊︎", "♋︎", "♌︎", "♍︎", "♎︎", "♏︎", "♐︎", "♑︎", "♒︎", "♓︎"][rawValue]
    }

    func name(_ lang: Lang) -> String {
        let fr = ["Bélier", "Taureau", "Gémeaux", "Cancer", "Lion", "Vierge",
                  "Balance", "Scorpion", "Sagittaire", "Capricorne", "Verseau", "Poissons"]
        let en = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
                  "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"]
        return lang == .fr ? fr[rawValue] : en[rawValue]
    }

    /// Feu, Terre, Air, Eau se suivent dans l'ordre du zodiaque.
    var element: ZodiacElement {
        [.fire, .earth, .air, .water][rawValue % 4]
    }

    /// (mois, jour) de début et de fin.
    private var range: (start: (Int, Int), end: (Int, Int)) {
        [
            ((3, 21), (4, 19)),  ((4, 20), (5, 20)),  ((5, 21), (6, 20)),
            ((6, 21), (7, 22)),  ((7, 23), (8, 22)),  ((8, 23), (9, 22)),
            ((9, 23), (10, 22)), ((10, 23), (11, 21)), ((11, 22), (12, 21)),
            ((12, 22), (1, 19)), ((1, 20), (2, 18)),  ((2, 19), (3, 20))
        ][rawValue]
    }

    func dates(_ lang: Lang) -> String {
        let f = DateFormatter()
        f.locale = lang.locale
        f.setLocalizedDateFormatFromTemplate("dMMM")
        let cal = Calendar(identifier: .gregorian)
        func d(_ md: (Int, Int)) -> String {
            let date = cal.date(from: DateComponents(year: 2001, month: md.0, day: md.1)) ?? Date()
            return f.string(from: date)
        }
        return "\(d(range.start)) – \(d(range.end))"
    }
}
