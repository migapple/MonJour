import WidgetKit
import SwiftUI

// Complications du cadran. Fichiers Shared/ à cocher aussi dans cette cible.

struct DayEntry: TimelineEntry {
    let date: Date
    let streak: Int
    let done: Int
    let dicton: String
    let puzzleNumber: Int
    let lang: Lang
}

struct DayProvider: TimelineProvider {
    func placeholder(in context: Context) -> DayEntry {
        DayEntry(date: .now, streak: 12, done: 1,
                 dicton: "Octobre en bruine, hiver en ruine.", puzzleNumber: 294, lang: .fr)
    }

    func getSnapshot(in context: Context, completion: @escaping (DayEntry) -> Void) {
        completion(entry(for: .now))
    }

    /// Une entrée maintenant + une à minuit (nouveau contenu), puis rechargement.
    func getTimeline(in context: Context, completion: @escaping (Timeline<DayEntry>) -> Void) {
        let now = Date.now
        let midnight = DayKey.nextMidnight(after: now)
        completion(Timeline(entries: [entry(for: now), entry(for: midnight)], policy: .after(midnight)))
    }

    private func entry(for date: Date) -> DayEntry {
        let store = DailyStore()
        let day = DayKey.index(for: date)
        let isToday = day == store.today
        return DayEntry(date: date,
                        streak: store.displayStreak(onDay: day),
                        done: isToday ? store.completedCount : 0,
                        dicton: DailyContent.dicton(day: day, lang: store.lang),
                        puzzleNumber: day + 1,
                        lang: store.lang)
    }
}

struct MonJourWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: DayEntry

    var body: some View {
        switch family {
        case .accessoryCircular:
            Gauge(value: Double(entry.done), in: 0...3) {
                Image(systemName: "flame")
            } currentValueLabel: {
                Text("\(entry.streak)")
            }
            .gaugeStyle(.accessoryCircular)
            .tint(Theme.gold)

        case .accessoryCorner:
            // Coins des cadrans Infographe / Méridien… : flamme + série en arc
            Image(systemName: "flame.fill")
                .font(.system(size: 20, weight: .semibold))
                .foregroundStyle(Theme.gold)
                .widgetAccentable()
                .widgetLabel {
                    Text(L10n.f("streakDays", entry.lang, entry.streak))
                }

        case .accessoryInline:
            Text("\(L10n.t("appName", entry.lang)) \(entry.done)/3")

        default: // .accessoryRectangular
            VStack(alignment: .leading, spacing: 1) {
                Text("\(L10n.t("appName", entry.lang).uppercased()) · \(entry.done)/3")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Theme.gold)
                    .widgetAccentable()
                Text(entry.dicton)
                    .font(.system(size: 14, weight: .semibold))
                    .lineLimit(2)
                Text(L10n.f("puzzle", entry.lang, entry.puzzleNumber))
                    .font(.system(size: 11))
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

@main
struct MonJourWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonJour", provider: DayProvider()) { entry in
            MonJourWidgetView(entry: entry)
                .containerBackground(for: .widget) { Color.black }
        }
        .configurationDisplayName("Mon Jour")
        .description("Dicton, horoscope et mot du jour.")
        .supportedFamilies([.accessoryCircular, .accessoryCorner, .accessoryRectangular, .accessoryInline])
    }
}
